package cronometro;

import javax.swing.Timer;
import java.util.*;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Alarma extends javax.swing.JFrame implements ActionListener{

    
    
    private Timer miTimer;
private int minutos;
private int segundos;
private boolean pospuesto;
private int tiempoPosponer;
private boolean stop;

    
    public Alarma() {
        
        initComponents();
        
        Lfecha.setText(fecha());
        
        setLocationRelativeTo(null);
        t=new Timer(10,acciones);
        
        
       
        Timer timer = new Timer(1000, this);
        timer.start();

        
        
       
        
       //setLocationRelativeTo(null);
        
        miTimer = new Timer(1000, new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (!pospuesto) {
                segundos--;
                if (segundos < 0) {
                    segundos = 10;
                    minutos--;
                }
            } else {
                tiempoPosponer--;
                if (tiempoPosponer <= 0) {
                    posponerAlarma();
                } else {
                    actualizarLabelTiempo();
                }
            }
            if (minutos == 0 && segundos == 0) {
                int respuesta = JOptionPane.showOptionDialog(null, "¡Alarma!", "Alarma",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
                if (respuesta == JOptionPane.OK_OPTION) {
                    posponerAlarma();
                }
            }
            if (stop){
                detenerTimer();
            } else {
                actualizarLabelTiempo();
            }
        }
    });
        
    }    
    
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {                             
                
        Date now = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("hh:mm:ss a");
        String hora = formatter.format(now);
        HoraActual.setText(hora);
    }
    
    
   
    

                                
                             
                              
                                
                                
                                
                                
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Lfecha = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        HoraActual = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        labelTiempo = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        botonIniciar = new javax.swing.JButton();
        botonParar = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Crono = new javax.swing.JLabel();
        iniciar = new javax.swing.JButton();
        pausar = new javax.swing.JButton();
        detener = new javax.swing.JButton();
        comboBoxSegundos = new javax.swing.JComboBox<>();
        comboBoxMinutos = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(481, 717));

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setPreferredSize(new java.awt.Dimension(430, 717));

        Lfecha.setFont(new java.awt.Font("Segoe UI Black", 3, 18)); // NOI18N
        Lfecha.setForeground(new java.awt.Color(255, 255, 255));
        Lfecha.setText("DD/MM/YYYY");
        Lfecha.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 102)));

        jLabel5.setForeground(new java.awt.Color(51, 255, 0));
        jLabel5.setText("FECHA");

        HoraActual.setFont(new java.awt.Font("Segoe UI Black", 3, 18)); // NOI18N
        HoraActual.setForeground(new java.awt.Color(255, 255, 255));
        HoraActual.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        HoraActual.setText("00:00:00");
        HoraActual.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 102)));

        jLabel3.setForeground(new java.awt.Color(51, 255, 0));
        jLabel3.setText("HORA");

        jLabel2.setFont(new java.awt.Font("Segoe UI Historic", 1, 36)); // NOI18N
        jLabel2.setForeground(java.awt.Color.orange);
        jLabel2.setText("TEMPORIZADOR");

        labelTiempo.setFont(new java.awt.Font("Segoe UI Historic", 0, 24)); // NOI18N
        labelTiempo.setForeground(new java.awt.Color(255, 255, 255));
        labelTiempo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelTiempo.setText("00:00:00");

        jLabel4.setFont(new java.awt.Font("Segoe UI Historic", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 102, 0));
        jLabel4.setText("TIMER");

        jLabel7.setFont(new java.awt.Font("Segoe UI Historic", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 255, 204));
        jLabel7.setText("Segundos");

        botonIniciar.setFont(new java.awt.Font("Segoe UI Historic", 2, 18)); // NOI18N
        botonIniciar.setForeground(new java.awt.Color(0, 204, 204));
        botonIniciar.setText("Iniciar");
        botonIniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonIniciarActionPerformed(evt);
            }
        });

        botonParar.setFont(new java.awt.Font("Segoe UI Historic", 2, 18)); // NOI18N
        botonParar.setForeground(new java.awt.Color(0, 204, 204));
        botonParar.setText("Parar");
        botonParar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonPararActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N

        jPanel2.setBackground(new java.awt.Color(255, 153, 0));

        jLabel1.setFont(new java.awt.Font("Leelawadee UI Semilight", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 153));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("CRONÓMETRO");

        Crono.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Crono.setForeground(new java.awt.Color(255, 255, 255));
        Crono.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Crono.setText("00:00:00");
        Crono.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 255)));

        iniciar.setFont(new java.awt.Font("Segoe UI Historic", 2, 18)); // NOI18N
        iniciar.setForeground(javax.swing.UIManager.getDefaults().getColor("Actions.Red"));
        iniciar.setText("Iniciar");
        iniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iniciarActionPerformed(evt);
            }
        });

        pausar.setFont(new java.awt.Font("Segoe UI Historic", 2, 18)); // NOI18N
        pausar.setForeground(javax.swing.UIManager.getDefaults().getColor("Actions.Red"));
        pausar.setText("Pausar");
        pausar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pausarActionPerformed(evt);
            }
        });

        detener.setFont(new java.awt.Font("Segoe UI Historic", 2, 18)); // NOI18N
        detener.setForeground(javax.swing.UIManager.getDefaults().getColor("Actions.Red"));
        detener.setText("Detener");
        detener.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                detenerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(89, 89, 89)
                        .addComponent(iniciar)
                        .addGap(41, 41, 41)
                        .addComponent(pausar)
                        .addGap(46, 46, 46)
                        .addComponent(detener)))
                .addContainerGap(50, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(Crono, javax.swing.GroupLayout.PREFERRED_SIZE, 367, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(31, 31, 31)
                .addComponent(Crono, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(iniciar)
                    .addComponent(pausar)
                    .addComponent(detener))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        comboBoxSegundos.setFont(new java.awt.Font("Segoe UI Black", 3, 18)); // NOI18N
        comboBoxSegundos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59" }));

        comboBoxMinutos.setFont(new java.awt.Font("Segoe UI Black", 3, 18)); // NOI18N
        comboBoxMinutos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59" }));

        jLabel9.setFont(new java.awt.Font("Segoe UI Historic", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 255, 204));
        jLabel9.setText("Minutos");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(jLabel5)
                        .addGap(238, 238, 238)
                        .addComponent(jLabel3))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(432, 432, 432)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addComponent(labelTiempo, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(116, 116, 116)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(155, 155, 155)
                                .addComponent(botonIniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(comboBoxMinutos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(14, 14, 14)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(46, 46, 46)
                                .addComponent(botonParar, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(56, 56, 56)
                                .addComponent(comboBoxSegundos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(173, 173, 173)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(Lfecha)
                                .addGap(141, 141, 141)
                                .addComponent(HoraActual, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(287, 287, 287))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(HoraActual, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Lfecha))
                .addGap(59, 59, 59)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labelTiempo, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(comboBoxMinutos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(comboBoxSegundos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(jLabel4)))
                .addGap(45, 45, 45)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonParar, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonIniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(53, 53, 53))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 502, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private Timer t;
    private int h, m, s, cs;
    private ActionListener acciones=new ActionListener(){//objetooooo
        
        @Override
        public void actionPerformed(ActionEvent ae){
            
                    
            cs++;
            if(cs==100){
                cs=0;
                ++s;
            }
            if(s==100){
                s=0;
                ++m;
            }
            if(m==100){
                m=0;
                ++h;
            }
            actualizarLabel();
            
        }
    };
    private void actualizarLabel(){
        String tiempo=(h<=9?"0":"")+h+":"+(m<=9?"0":"")+m+":"+(s<=9?"0":"")+s+":"+(cs<=9?"0":"")+cs;
        Crono.setText(tiempo);
        
    }
    
    
    
    private void pausarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pausarActionPerformed
     t.stop();
     iniciar.setEnabled(true);
     
     pausar.setEnabled(false);
     
        


    }//GEN-LAST:event_pausarActionPerformed

    private void iniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iniciarActionPerformed

    
     t.start();
     iniciar.setEnabled(false);
     iniciar.setText("reanudar");
     pausar.setEnabled(true);
     detener.setEnabled(true);
    }//GEN-LAST:event_iniciarActionPerformed

    private void detenerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_detenerActionPerformed

        if(t.isRunning()){
            t.stop();
            iniciar.setEnabled(true);
        }
        iniciar.setText("Iniciar");
        pausar.setEnabled(false);
        detener.setEnabled(false);
        h=0;m=0;s=0;cs=0;
        actualizarLabel();



    }//GEN-LAST:event_detenerActionPerformed
              
 
    
    
    
        

    private void botonIniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonIniciarActionPerformed

       iniciarTimer();
        
    }//GEN-LAST:event_botonIniciarActionPerformed

    private void botonPararActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonPararActionPerformed

        miTimer.stop();
        labelTiempo.setText("00:00");
                      
    }//GEN-LAST:event_botonPararActionPerformed

    public static String fecha(){
        Date fecha = new Date();
        SimpleDateFormat FormatoFecha=new SimpleDateFormat("dd/MM/YYYY");
        return FormatoFecha.format(fecha);
    }
    
    public static void main(String args[]) {
        
        Alarma alarma = new Alarma();
        
        
        
        
        
        new Alarma();
        Alarma reloj = new Alarma();
        reloj.setVisible(true);
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            
            public void run() {
                new Alarma().setVisible(true);
                
                
                
                
                
                
                
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Crono;
    private javax.swing.JLabel HoraActual;
    private javax.swing.JLabel Lfecha;
    private javax.swing.JButton botonIniciar;
    private javax.swing.JButton botonParar;
    private javax.swing.JComboBox<String> comboBoxMinutos;
    private javax.swing.JComboBox<String> comboBoxSegundos;
    private javax.swing.JButton detener;
    private javax.swing.JButton iniciar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel labelTiempo;
    private javax.swing.JButton pausar;
    // End of variables declaration//GEN-END:variables

    private void iniciarTimer() {
    minutos = Integer.parseInt(comboBoxMinutos.getSelectedItem().toString());
    segundos = Integer.parseInt(comboBoxSegundos.getSelectedItem().toString());
    pospuesto = false;
    tiempoPosponer = 0;
    actualizarLabelTiempo();
    miTimer.start();
}

private void detenerTimer() {
    stop = true;
    miTimer.stop();
    minutos = 0;
    segundos = 0;
    pospuesto = false;
    tiempoPosponer = 0;
    actualizarLabelTiempo();
}

private void actualizarLabelTiempo() {
    if (!pospuesto) {
        labelTiempo.setText(String.format("%02d:%02d", minutos, segundos));
    } else {
        labelTiempo.setText(String.format("Pospuesto (%d)", tiempoPosponer));
    }
}

private void posponerAlarma() {
    tiempoPosponer = 10;
    pospuesto = true;
    miTimer.stop();
    actualizarLabelTiempo();
    JOptionPane.showMessageDialog(null, "Pospuesto");
    miTimer.start();
    pospuesto = false;
    tiempoPosponer = 0;
    stop = false;
    actualizarLabelTiempo();
}

     

    

}


  

