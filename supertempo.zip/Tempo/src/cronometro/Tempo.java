package cronometro;


public class Tempo {

    
    public static void main(String[] args) {
        
        
        
    }
    
}
